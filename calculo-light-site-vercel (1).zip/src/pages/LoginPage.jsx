import SectionTitle from "../components/SectionTitle";
import LoginCard from "../components/LoginCard";

const pages = [
  ["/", "Home"],
  ["/recursos", "Recursos"],
  ["/como-funciona", "Como funciona"],
  ["/planos", "Planos"],
  ["/vendas", "Página SaaS"],
  ["/login", "Login"],
  ["/contato", "Contato"],
  ["/demo", "Demonstração"],
  ["/faq", "Perguntas frequentes"],
  ["/suporte", "Suporte"],
];

export default function LoginPage() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
      <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
        <div>
          <SectionTitle badge="Login" title="Área de acesso pronta para integração real" description="A estrutura abaixo já pode consumir o backend do sistema. Basta apontar a API para seu domínio oficial." />
          <div className="mt-8 rounded-[2rem] border border-slate-200 bg-slate-50 p-6">
            <div className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">Rotas sugeridas do site</div>
            <div className="mt-4 grid gap-3">
              {pages.map(([route, label]) => (
                <div key={route} className="flex items-center justify-between rounded-2xl bg-white px-4 py-3 text-sm shadow-sm">
                  <span className="font-medium text-slate-800">{label}</span>
                  <span className="text-slate-500">www.calculolight.com{route}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <LoginCard />
      </div>
    </section>
  );
}
