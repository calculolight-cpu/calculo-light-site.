import SectionTitle from "../components/SectionTitle";

const faqs = [
  ["Posso alterar textos e preços depois?", "Sim. O site foi montado em React com seções claras, facilitando futuras atualizações."],
  ["Posso ligar esse site ao meu backend?", "Sim. A área de login já está preparada para consumir a API do Cálculo Light."],
  ["Posso publicar no Vercel?", "Sim. A estrutura foi pensada para ser publicada como projeto web moderno."],
  ["Posso vender para outras empresas?", "Sim. O modelo do site já apresenta planos SaaS e estrutura de revenda white-label."],
];

export default function FaqPage() {
  return (
    <section className="bg-slate-50">
      <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
        <SectionTitle badge="Perguntas frequentes" title="Base pronta para atendimento comercial" description="Use esta seção para tirar dúvidas e reduzir objeções na hora da venda." />
        <div className="mt-10 grid gap-4">
          {faqs.map(([question, answer]) => (
            <div key={question} className="rounded-[1.75rem] border border-slate-200 bg-white p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-slate-950">{question}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-600">{answer}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
