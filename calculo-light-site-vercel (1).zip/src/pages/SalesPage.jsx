import SectionTitle from "../components/SectionTitle";

const bullets = [
  "Reduz tempo de orçamento",
  "Organiza produção",
  "Gera PDF e Word",
  "Ajuda a vender com aparência profissional",
  "Pode ser revendido em modelo white-label",
];

export default function SalesPage() {
  return (
    <section className="bg-slate-950 text-white">
      <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
        <SectionTitle badge="Página de vendas SaaS" title="Uma oferta clara para transformar o site em máquina de vendas" description="Use esta página em anúncios, Instagram, WhatsApp e demonstrações comerciais." />
        <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_1fr]">
          <div className="rounded-[2rem] border border-white/10 bg-white/5 p-6">
            <h3 className="text-2xl font-bold">Por que o Cálculo Light vende?</h3>
            <div className="mt-5 space-y-3 text-sm text-slate-200">
              {bullets.map((item) => <div key={item} className="rounded-2xl bg-white/5 px-4 py-3">{item}</div>)}
            </div>
          </div>
          <div className="rounded-[2rem] border border-yellow-400/30 bg-yellow-400/10 p-6 text-slate-50">
            <div className="text-sm font-semibold uppercase tracking-[0.25em] text-yellow-300">Oferta</div>
            <h3 className="mt-3 text-3xl font-bold">Comece a vender esquadrias com mais velocidade e organização</h3>
            <p className="mt-4 text-slate-200">Ideal para fábricas, serralherias, vidraçarias e empresas que querem profissionalizar orçamento, produção e gestão.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <button className="rounded-2xl bg-yellow-400 px-5 py-3 text-sm font-semibold text-slate-950">Quero uma demonstração</button>
              <button className="rounded-2xl border border-white/15 px-5 py-3 text-sm font-semibold text-white">Ver planos</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
