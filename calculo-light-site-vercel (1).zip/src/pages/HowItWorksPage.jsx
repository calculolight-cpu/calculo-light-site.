import SectionTitle from "../components/SectionTitle";

export default function HowItWorksPage() {
  const steps = [
    ["1", "Cadastrar cliente e obra", "Organize o histórico comercial e os dados da obra."],
    ["2", "Escolher linha e tipologia", "Configure medidas, cor, vidro e acessórios."],
    ["3", "Gerar orçamento", "O sistema monta preço e gera PDF e Word."],
    ["4", "Produzir e instalar", "Transforme orçamento em ordem de produção e acompanhe etapas."],
  ];
  return (
    <section className="bg-slate-50">
      <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[0.95fr_1.05fr]">
          <div><SectionTitle badge="Como funciona" title="Fluxo claro para apresentar e vender" description="Use esta página para explicar rapidamente o funcionamento do sistema." /></div>
          <div className="grid gap-4">
            {steps.map(([n, title, desc]) => (
              <div key={title} className="flex gap-4 rounded-[1.75rem] border border-slate-200 bg-white p-5 shadow-sm">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-slate-950 text-sm font-bold text-white">{n}</div>
                <div><h3 className="text-lg font-semibold text-slate-950">{title}</h3><p className="mt-1 text-sm leading-6 text-slate-600">{desc}</p></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
