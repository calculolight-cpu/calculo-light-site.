import { Link } from "react-router-dom";

const resources = ["Orçamento automático", "Lista de corte e plano de barras", "Produção por etapas", "Word e PDF reais"];

export default function HomePage() {
  return (
    <>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(250,204,21,0.18),_transparent_28%),radial-gradient(circle_at_left,_rgba(15,23,32,0.05),_transparent_35%)]" />
        <div className="relative mx-auto grid max-w-7xl gap-12 px-6 py-20 lg:grid-cols-[1.05fr_0.95fr] lg:px-8 lg:py-28">
          <div>
            <div className="inline-flex rounded-full border border-yellow-200 bg-yellow-50 px-3 py-1 text-sm font-medium text-yellow-800">Site oficial do Cálculo Light</div>
            <h1 className="mt-6 max-w-3xl text-4xl font-bold tracking-tight text-slate-950 lg:text-6xl">O sistema completo para calcular, produzir e vender esquadrias de alumínio.</h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">Estrutura pronta para publicar no Vercel, vender planos SaaS e integrar login real do sistema.</p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link to="/vendas" className="rounded-2xl bg-slate-950 px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-slate-800">Ver página de vendas</Link>
              <Link to="/login" className="rounded-2xl border border-slate-300 px-6 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50">Abrir login</Link>
            </div>
            <div className="mt-10 grid max-w-2xl grid-cols-2 gap-4 sm:grid-cols-4">
              {[
                ["10", "Páginas"],
                ["SaaS", "Multiempresa"],
                ["Word", "Editável"],
                ["PDF", "Comercial"],
              ].map(([value, label]) => (
                <div key={label} className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
                  <div className="text-2xl font-bold text-slate-950">{value}</div>
                  <div className="mt-1 text-sm text-slate-500">{label}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="w-full max-w-xl rounded-[2rem] border border-slate-200 bg-white p-5 shadow-xl shadow-slate-200/60">
              <div className="rounded-[1.5rem] bg-slate-950 p-5 text-white">
                <div className="flex items-center justify-between text-sm text-slate-300"><span>Painel do sistema</span><span>Visual profissional</span></div>
                <div className="mt-5 grid gap-4 md:grid-cols-2">
                  <div className="rounded-2xl bg-white/10 p-4"><div className="text-xs text-slate-300">Orçamento</div><div className="mt-2 text-2xl font-bold">R$ 3.350,00</div><div className="mt-2 text-sm text-slate-300">Porta Pivotante ACM</div></div>
                  <div className="rounded-2xl bg-white/10 p-4"><div className="text-xs text-slate-300">Produção</div><div className="mt-2 text-2xl font-bold">52</div><div className="mt-2 text-sm text-slate-300">Ordens em andamento</div></div>
                </div>
                <div className="mt-4 rounded-2xl bg-white/5 p-4">
                  <div className="text-sm font-medium">Módulos em destaque</div>
                  <div className="mt-3 grid grid-cols-2 gap-3 text-sm text-slate-300">
                    {resources.map((item) => <div key={item} className="rounded-xl bg-white/5 px-3 py-2">{item}</div>)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
