import SectionTitle from "../components/SectionTitle";

export default function ContactPage() {
  return (
    <section className="bg-white">
      <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1fr_0.95fr] lg:items-center">
          <div><SectionTitle badge="Contato" title="Pronto para publicar no Vercel e evoluir depois" description="Use esta página para captar demonstrações, contatos e mensagens comerciais." /></div>
          <div className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
            <div className="grid gap-4">
              <input className="rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400" placeholder="Seu nome" />
              <input className="rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400" placeholder="Seu WhatsApp" />
              <input className="rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400" placeholder="Seu e-mail" />
              <textarea className="min-h-[120px] rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400" placeholder="Conte o que você precisa" />
              <button className="rounded-2xl bg-slate-950 px-4 py-3 text-sm font-semibold text-white transition hover:bg-slate-800">Enviar contato</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
