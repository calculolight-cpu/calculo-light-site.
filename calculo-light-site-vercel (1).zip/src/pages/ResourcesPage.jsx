import SectionTitle from "../components/SectionTitle";

const resources = [
  { title: "Orçamento automático", description: "Calcule perfis, vidro, acessórios, mão de obra, instalação e valor final." },
  { title: "Lista de corte e plano de barras", description: "Transforme o orçamento em produção com cortes por perfil, sobra e desperdício." },
  { title: "Produção por etapas", description: "Controle separação, corte, montagem, vidro, pintura, entrega e instalação." },
  { title: "White-label", description: "Venda o sistema para outras empresas com identidade visual própria." },
  { title: "Word e PDF reais", description: "Gere documentos editáveis e comerciais com aparência profissional." },
  { title: "Base pronta para crescer", description: "Código organizado para novas páginas, módulos, integrações e vendas." },
];

export default function ResourcesPage() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
      <SectionTitle badge="Recursos" title="Tudo que o Cálculo Light pode apresentar no site" description="Página pronta para mostrar recursos técnicos, comerciais e diferenciais do sistema." />
      <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {resources.map((feature) => (
          <div key={feature.title} className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-yellow-100 text-lg font-bold text-yellow-800">CL</div>
            <h3 className="mt-5 text-lg font-semibold text-slate-950">{feature.title}</h3>
            <p className="mt-3 text-sm leading-6 text-slate-600">{feature.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
