import SectionTitle from "../components/SectionTitle";

const plans = [
  { name: "Básico", price: "R$ 59/mês", items: ["Catálogo", "Orçamentos", "PDF", "Word"] },
  { name: "Profissional", price: "R$ 119/mês", items: ["Tudo do Básico", "Cálculo automático", "Lista de corte", "Simulador visual"], featured: true },
  { name: "Fábrica", price: "R$ 249/mês", items: ["Tudo do Profissional", "Produção", "Plano de barras", "Controle por etapas"] },
];

export default function PlansPage() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
      <SectionTitle badge="Planos" title="Base pronta para vender SaaS" description="Estrutura de preços organizada para uso próprio e revenda white-label." center />
      <div className="mt-10 grid gap-6 lg:grid-cols-3">
        {plans.map((plan) => (
          <div key={plan.name} className={`rounded-[2rem] border p-6 shadow-sm ${plan.featured ? "border-slate-950 bg-slate-950 text-white" : "border-slate-200 bg-white text-slate-900"}`}>
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold">{plan.name}</h3>
              {plan.featured ? <span className="rounded-full bg-yellow-400 px-3 py-1 text-xs font-bold text-slate-950">Mais vendido</span> : null}
            </div>
            <div className="mt-4 text-3xl font-bold">{plan.price}</div>
            <div className={`mt-2 text-sm ${plan.featured ? "text-slate-300" : "text-slate-500"}`}>Cobrança mensal por empresa</div>
            <div className="mt-6 space-y-3">
              {plan.items.map((item) => <div key={item} className={`rounded-2xl px-4 py-3 text-sm ${plan.featured ? "bg-white/10 text-slate-100" : "bg-slate-50 text-slate-700"}`}>{item}</div>)}
            </div>
            <button className={`mt-6 w-full rounded-2xl px-4 py-3 text-sm font-semibold transition ${plan.featured ? "bg-yellow-400 text-slate-950 hover:bg-yellow-300" : "bg-slate-950 text-white hover:bg-slate-800"}`}>Escolher plano</button>
          </div>
        ))}
      </div>
    </section>
  );
}
