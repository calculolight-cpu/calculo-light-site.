import SectionTitle from "../components/SectionTitle";
export default function DemoPage() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
      <SectionTitle badge="Demonstração" title="Página de demonstração" description="Use esta rota para vídeos, prints do sistema e formulário para agendar apresentação." />
    </section>
  );
}
