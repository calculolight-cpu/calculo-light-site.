import SectionTitle from "../components/SectionTitle";
export default function SupportPage() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
      <SectionTitle badge="Suporte" title="Página de suporte" description="Use esta rota para base de conhecimento, onboarding, chamados e contato técnico." />
    </section>
  );
}
