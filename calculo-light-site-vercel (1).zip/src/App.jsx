import { Routes, Route } from "react-router-dom";
import SiteLayout from "./components/SiteLayout";
import HomePage from "./pages/HomePage";
import ResourcesPage from "./pages/ResourcesPage";
import HowItWorksPage from "./pages/HowItWorksPage";
import PlansPage from "./pages/PlansPage";
import SalesPage from "./pages/SalesPage";
import LoginPage from "./pages/LoginPage";
import ContactPage from "./pages/ContactPage";
import FaqPage from "./pages/FaqPage";
import DemoPage from "./pages/DemoPage";
import SupportPage from "./pages/SupportPage";

export default function App() {
  return (
    <SiteLayout>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/recursos" element={<ResourcesPage />} />
        <Route path="/como-funciona" element={<HowItWorksPage />} />
        <Route path="/planos" element={<PlansPage />} />
        <Route path="/vendas" element={<SalesPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/contato" element={<ContactPage />} />
        <Route path="/faq" element={<FaqPage />} />
        <Route path="/demo" element={<DemoPage />} />
        <Route path="/suporte" element={<SupportPage />} />
      </Routes>
    </SiteLayout>
  );
}
