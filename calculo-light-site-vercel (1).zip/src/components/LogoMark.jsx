export default function LogoMark({ compact = false }) {
  return (
    <div className="flex items-center gap-3">
      <div className="relative flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-950 shadow-sm ring-1 ring-slate-800/10">
        <div className="absolute inset-2 rounded-xl border-2 border-yellow-400" />
        <div className="absolute h-1 w-5 rotate-45 rounded-full bg-yellow-400 translate-x-[2px] translate-y-[5px]" />
        <div className="absolute h-1 w-3 -rotate-45 rounded-full bg-yellow-400 -translate-x-[6px] translate-y-[7px]" />
        <div className="absolute left-[11px] top-[13px] h-1 w-4 rounded-full bg-slate-200/90" />
        <div className="absolute left-[11px] top-[21px] h-1 w-6 rounded-full bg-slate-200/70" />
      </div>
      {!compact && (
        <div>
          <div className="text-2xl font-bold tracking-tight text-slate-950">Cálculo <span className="text-yellow-500">Light</span></div>
          <div className="text-xs text-slate-500">Sistema inteligente para esquadrias</div>
        </div>
      )}
    </div>
  );
}
