import { Link, NavLink } from "react-router-dom";
import LogoMark from "./LogoMark";

const menu = [
  ["/", "Home"],
  ["/recursos", "Recursos"],
  ["/como-funciona", "Como funciona"],
  ["/planos", "Planos"],
  ["/vendas", "Página SaaS"],
  ["/login", "Login"],
  ["/contato", "Contato"],
];

export default function SiteLayout({ children }) {
  return (
    <div className="min-h-screen bg-white text-slate-900">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-8">
          <Link to="/"><LogoMark /></Link>
          <nav className="hidden items-center gap-6 lg:flex">
            {menu.map(([to, label]) => (
              <NavLink key={to} to={to} className={({ isActive }) => `text-sm transition ${isActive ? "text-slate-950 font-semibold" : "text-slate-600 hover:text-slate-950"}`}>
                {label}
              </NavLink>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <Link to="/login" className="rounded-2xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50">Entrar</Link>
            <Link to="/contato" className="rounded-2xl bg-slate-950 px-4 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-slate-800">Solicitar demonstração</Link>
          </div>
        </div>
      </header>
      <main>{children}</main>
      <footer className="border-t border-slate-200 bg-slate-50">
        <div className="mx-auto grid max-w-7xl gap-8 px-6 py-10 lg:grid-cols-[1fr_auto] lg:px-8">
          <div>
            <LogoMark />
            <p className="mt-4 max-w-xl text-sm leading-6 text-slate-600">Plataforma para orçamento, produção e venda de esquadrias, pronta para evoluir com novas páginas, integrações e recursos SaaS.</p>
          </div>
          <div className="grid grid-cols-2 gap-6 text-sm text-slate-600">
            {menu.map(([to, label]) => <NavLink key={to} to={to} className="hover:text-slate-950">{label}</NavLink>)}
          </div>
        </div>
      </footer>
    </div>
  );
}
