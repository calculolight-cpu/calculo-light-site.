export default function SectionTitle({ badge, title, description, center = false }) {
  return (
    <div className={center ? "mx-auto max-w-3xl text-center" : "max-w-3xl"}>
      {badge ? <div className="text-sm font-semibold uppercase tracking-[0.25em] text-yellow-600">{badge}</div> : null}
      <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-950 lg:text-4xl">{title}</h2>
      {description ? <p className="mt-4 text-lg text-slate-600">{description}</p> : null}
    </div>
  );
}
