const API_BASE = import.meta.env.VITE_API_BASE || "https://api.calculolight.com.br";

export default function LoginCard() {
  const handleSubmit = async (e) => {
    e.preventDefault();
    const email = e.currentTarget.email.value;
    const password = e.currentTarget.password.value;
    try {
      const response = await fetch(`${API_BASE}/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await response.json();
      if (!response.ok) {
        alert(data.error || "Falha no login");
        return;
      }
      localStorage.setItem("cl_auth", JSON.stringify(data));
      alert("Login realizado com sucesso.");
    } catch (error) {
      alert("Não foi possível conectar ao backend. Ajuste a variável VITE_API_BASE.");
    }
  };

  return (
    <div className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
      <div className="mb-5">
        <div className="text-lg font-semibold text-slate-950">Área de login</div>
        <div className="text-sm text-slate-500">Acesso ao sistema SaaS</div>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="mb-2 block text-sm font-medium text-slate-700">E-mail</label>
          <input name="email" type="email" defaultValue="master@calculolight.com" className="w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm outline-none transition focus:border-slate-950" />
        </div>
        <div>
          <label className="mb-2 block text-sm font-medium text-slate-700">Senha</label>
          <input name="password" type="password" defaultValue="123456" className="w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm outline-none transition focus:border-slate-950" />
        </div>
        <button className="w-full rounded-2xl bg-slate-950 px-4 py-3 text-sm font-semibold text-white transition hover:bg-slate-800">Entrar no sistema</button>
      </form>
      <div className="mt-4 text-xs text-slate-500">Para produção, configure <span className="font-semibold">VITE_API_BASE</span> com a URL pública da sua API.</div>
    </div>
  );
}
