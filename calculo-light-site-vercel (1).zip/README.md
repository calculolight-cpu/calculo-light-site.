# Cálculo Light Site — pronto para Vercel

## O que este projeto inclui
- React + Vite
- Rotas com react-router-dom
- Home
- Recursos
- Como funciona
- Planos
- Página de vendas SaaS
- Login integrado ao backend
- Contato
- FAQ
- Demo
- Suporte
- `vercel.json` pronto

## Rodar localmente
```bash
npm install
npm run dev
```

## Publicar no Vercel
1. Suba esta pasta para um repositório GitHub
2. No Vercel, clique em Add New Project
3. Importe o repositório
4. Deploy

## Variável de ambiente
Crie no Vercel:
- `VITE_API_BASE=https://api.calculolight.com.br`

## Observação
A área de login já chama `/api/auth/login`.
Basta seu backend estar publicado.
